console.log('Hello World!');

function bt() {
      alert("Merci bcp mon amour" )
      // Tab to edit
}

function by() {
      alert("salope tu me trompe")
      // Tab to edit
}


